package ipatolli;

public class ConfigurarJugador extends javax.swing.JFrame {

    private int tamanioAspa;
    private String nombrePartida;
    private String nombreJugador;

    public ConfigurarJugador(String nombreJugador) {
        this.nombreJugador = nombreJugador;

        initComponents();
        this.botonEmpezar.setEnabled(false);
        this.botonEmpezar.setVisible(false);
    }

    public ConfigurarJugador(int tamanioAspa, String nombrePartida, String nombreJugador) {
        this.tamanioAspa = tamanioAspa;
        this.nombreJugador = nombreJugador;
        this.nombrePartida = nombrePartida;
        initComponents();
        labelNombre1.setText(nombreJugador);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        labelNombre1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        labelNombre2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        labelNombre3 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        labelNombre4 = new javax.swing.JLabel();
        botonEmpezar = new javax.swing.JButton();
        botonRegresar = new javax.swing.JButton();
        comboBoxColor1 = new javax.swing.JComboBox<>();
        comboBoxColor2 = new javax.swing.JComboBox<>();
        comboBoxColor3 = new javax.swing.JComboBox<>();
        comboBoxColor4 = new javax.swing.JComboBox<>();
        comboBoxlListo2 = new javax.swing.JCheckBox();
        comboBoxlListo4 = new javax.swing.JCheckBox();
        comboBoxlListo3 = new javax.swing.JCheckBox();
        comboBoxlListo1 = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Jugador 1 : ");

        labelNombre1.setText("Vacío");

        jLabel3.setText("Jugador 2");

        labelNombre2.setText("Vacío");

        jLabel5.setText("Jugador 3:");

        labelNombre3.setText("Vacío");

        jLabel7.setText("Jugador 4: ");

        labelNombre4.setText("Vacío");

        botonEmpezar.setText("Empezar Partida");
        botonEmpezar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonEmpezarActionPerformed(evt);
            }
        });

        botonRegresar.setText("Regresar");
        botonRegresar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                botonRegresarActionPerformed(evt);
            }
        });

        comboBoxColor1.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Rojo", "Azul", "Verde", "Negro", "Blanco", "Morado", "Rosa", "Gris", "Naranja" }));

        comboBoxColor2.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Azul", "Rojo", "Verde", "Negro", "Blanco", "Morado", "Rosa", "Gris", "Naranja" }));

        comboBoxColor3.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Verde", "Rojo", "Azul", "Negro", "Blanco", "Morado", "Rosa", "Gris", "Naranja" }));

        comboBoxColor4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Negro", "Rojo", "Azul", "Verde", "Blanco", "Morado", "Rosa", "Gris", "Naranja" }));

        comboBoxlListo2.setText("Listo");

        comboBoxlListo4.setText("Listo");

        comboBoxlListo3.setText("Listo");

        comboBoxlListo1.setText("Listo");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(37, 37, 37)
                                .addComponent(labelNombre1))
                            .addComponent(comboBoxColor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(94, 94, 94)
                                .addComponent(labelNombre3))
                            .addComponent(comboBoxColor3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5)
                            .addComponent(comboBoxlListo3)
                            .addComponent(comboBoxlListo1)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(botonEmpezar)))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(213, 213, 213)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(comboBoxlListo4)
                            .addComponent(comboBoxColor4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comboBoxColor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel7)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addGap(29, 29, 29)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(labelNombre4)
                                    .addComponent(labelNombre2)))
                            .addComponent(comboBoxlListo2))
                        .addContainerGap(30, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(botonRegresar)
                        .addContainerGap())))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(labelNombre1)
                    .addComponent(jLabel3)
                    .addComponent(labelNombre2))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxColor1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(comboBoxColor2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comboBoxlListo2)
                    .addComponent(comboBoxlListo1))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(labelNombre4))
                        .addGap(37, 37, 37)
                        .addComponent(comboBoxColor4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(comboBoxlListo4)
                            .addComponent(comboBoxlListo3)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel5)
                            .addComponent(labelNombre3))
                        .addGap(37, 37, 37)
                        .addComponent(comboBoxColor3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(botonRegresar)
                    .addComponent(botonEmpezar))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void botonRegresarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonRegresarActionPerformed
        this.dispose();
        new MenuPrincipal().setVisible(true);

    }//GEN-LAST:event_botonRegresarActionPerformed

    private void botonEmpezarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_botonEmpezarActionPerformed

        GUITablero tablero = new GUITablero(700, (int) tamanioAspa, nombrePartida);
        tablero.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_botonEmpezarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton botonEmpezar;
    private javax.swing.JButton botonRegresar;
    private javax.swing.JComboBox<String> comboBoxColor1;
    private javax.swing.JComboBox<String> comboBoxColor2;
    private javax.swing.JComboBox<String> comboBoxColor3;
    private javax.swing.JComboBox<String> comboBoxColor4;
    private javax.swing.JCheckBox comboBoxlListo1;
    private javax.swing.JCheckBox comboBoxlListo2;
    private javax.swing.JCheckBox comboBoxlListo3;
    private javax.swing.JCheckBox comboBoxlListo4;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel labelNombre1;
    private javax.swing.JLabel labelNombre2;
    private javax.swing.JLabel labelNombre3;
    private javax.swing.JLabel labelNombre4;
    // End of variables declaration//GEN-END:variables
}
