package ipatolli;

import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class GUITablero extends JPanel {

    private final int tamanioAspa;
    private final int casillas;
    private final int tileSize;

    public GUITablero(int size, int aspa, String nombrePartida) {
        this.setPreferredSize(new Dimension(size, size));

        this.tamanioAspa = aspa;
        casillas = this.tamanioAspa + 2;
        tileSize = size / casillas;

        JFrame f = new JFrame();
        f.setSize(size, size);
        Container c = this;
        c.setBackground(Color.MAGENTA);

        f.setTitle(nombrePartida);
        f.setContentPane(c);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.pack();
        f.setVisible(true);

    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        //Pintar el tablero completo de blanco
        g.setColor(new Color(
                231, 234, 234
        ));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.drawOval(0, 0, 2, 2);
        g.drawOval(2, 4, 2, 2);

        dibujoCasillas(casillas, tileSize, g);
        dibujoCasillasMeta(casillas, tileSize, g);
        dibujoTriangulos(casillas, tileSize, g);
        dibujoSeparaciones(casillas, tileSize, g);
        g.setColor(Color.red);
        drawCenteredCircle((Graphics2D) g, 50, 50,40);
        drawCenteredCircle((Graphics2D) g, 100, 50,40);
        drawCenteredCircle((Graphics2D) g, 50, 100,40);
        drawCenteredCircle((Graphics2D) g, 100, 100,40);
        drawCenteredCircle((Graphics2D) g, 50, 150,40);
        drawCenteredCircle((Graphics2D) g, 100, 150,40);
        g.setColor(Color.blue);
        drawCenteredCircle((Graphics2D) g, 50, 550,40);
        drawCenteredCircle((Graphics2D) g, 100, 550,40);
        drawCenteredCircle((Graphics2D) g, 50, 600,40);
        drawCenteredCircle((Graphics2D) g, 100, 600,40);
        drawCenteredCircle((Graphics2D) g, 50, 650,40);
        drawCenteredCircle((Graphics2D) g, 100, 650,40);
        g.setColor(Color.green);
        drawCenteredCircle((Graphics2D) g, 600, 50,40);
        drawCenteredCircle((Graphics2D) g, 650, 50,40);
        drawCenteredCircle((Graphics2D) g, 600, 100,40);
        drawCenteredCircle((Graphics2D) g, 650, 100,40);
        drawCenteredCircle((Graphics2D) g, 600, 150,40);
        drawCenteredCircle((Graphics2D) g, 650, 150,40);
        g.setColor(Color.yellow);
        drawCenteredCircle((Graphics2D) g, 600, 550,40);
        drawCenteredCircle((Graphics2D) g, 650, 550,40);
        drawCenteredCircle((Graphics2D) g, 600, 600,40);
        drawCenteredCircle((Graphics2D) g, 650, 600,40);
        drawCenteredCircle((Graphics2D) g, 600, 650,40);
        drawCenteredCircle((Graphics2D) g, 650, 650,40);
        
       

    }

    protected void dibujoCasillas(int casillas, int tileSize, Graphics g) {

        g.setColor(new Color(175, 209, 219));
        for (int i = 0; i < casillas; i++) {
            for (int j = 0; j < casillas; j++) {
                if ((i == (casillas / 2) - 1) || (i == (casillas / 2))) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                }
                if ((j == (casillas / 2) - 1) || (j == (casillas / 2))) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                }
            }
        }

    }

    protected void dibujoSeparaciones(int casillas, int tileSize, Graphics g) {
        g.setColor(Color.BLACK);

        for (int i = 0; i < casillas; i++) {
            for (int j = 0; j < casillas; j++) {
                if ((i == (casillas / 2) - 1) || (i == (casillas / 2))) {
                    g.drawRect(i * tileSize, j * tileSize, tileSize, tileSize);
                }
                if ((j == (casillas / 2) - 1) || (j == (casillas / 2))) {
                    g.drawRect(i * tileSize, j * tileSize, tileSize, tileSize);
                }
            }
        }
    }

    protected void dibujoCasillasMeta(int casillas, int tileSize, Graphics g) {
        g.setColor(new Color(249, 241, 107));
        for (int i = 0; i < casillas; i++) {
            for (int j = 0; j < casillas; j++) {
                if (((i == (casillas / 2)) && (j == (casillas / 2) - 2))) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                } else if ((i == (casillas / 2) - 1) && (j == (casillas / 2) + 1)) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                } else if ((i == (casillas / 2) - 2) && (j == (casillas / 2) - 1)) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                } else if ((i == (casillas / 2) + 1) && (j == (casillas / 2))) {
                    g.fillRect(i * tileSize, j * tileSize, tileSize, tileSize);
                }
            }
        }
    }

    protected void dibujoTriangulos(int casillas, int tileSize, Graphics g) {
        g.setColor(Color.BLACK);
        for (int i = 0; i < casillas; i++) {
            for (int j = 0; j < casillas; j++) {
                //Aspa Superior
                if (((i == (casillas / 2))) && (j == 1)) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, i * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 2)) && (j == 1)) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 1)) && (j == 2)) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 2)) && (j == 2)) {
                    g.drawLine((i - 2) * tileSize, (j + 1) * tileSize, (i - 1) * tileSize, (j) * tileSize);
                } //AspaInferior
                else if (((i == (casillas / 2))) && (j == (casillas - 3))) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, i * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 2)) && (j == (casillas - 3))) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 1)) && (j == (casillas - 2))) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } else if (((i == (casillas / 2) + 2)) && (j == (casillas - 2))) {
                    g.drawLine((i - 2) * tileSize, (j + 1) * tileSize, (i - 1) * tileSize, j * tileSize);
                } //AspaIzquierda
                else if ((i == 3) && (j == (casillas / 2))) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, i * tileSize, j * tileSize);
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } else if ((i == 4) && (j == ((casillas / 2)) - 1)) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                    g.drawLine((i - 3) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);
                } //AspaDerecha
                else if ((i == (casillas - 1)) && (j == (casillas / 2))) {
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, i * tileSize, j * tileSize);
                    g.drawLine((i - 1) * tileSize, (j + 1) * tileSize, (i - 2) * tileSize, j * tileSize);

                } else if ((i == (casillas - 1)) && (j == ((casillas / 2) - 1))) {
                    g.drawLine((i - 1) * tileSize, (j) * tileSize, (i - 2) * tileSize, (j + 1) * tileSize);
                    g.drawLine((i - 1) * tileSize, (j) * tileSize, (i) * tileSize, (j + 1) * tileSize);
                }
            }
        }
    }

    public void drawCenteredCircle(Graphics2D g, int x, int y, int r) {
        x = x - (r / 2);
        y = y - (r / 2);
        g.fillOval(x, y, r, r);
        
        
    }

}
