/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosJuego;

/**
 *
 * @author Abrahan Barrios
 */
public class Ficha {
    
    private String color;
    private String posicionCasilla;

    public Ficha(String color, String posicionCasilla) {
        this.color = color;
        this.posicionCasilla = posicionCasilla;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getPosicionCasilla() {
        return posicionCasilla;
    }

    public void setPosicionCasilla(String posicionCasilla) {
        this.posicionCasilla = posicionCasilla;
    }
    
    
    
}
