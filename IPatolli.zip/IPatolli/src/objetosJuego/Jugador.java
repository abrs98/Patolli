/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosJuego;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Abrahan Barrios
 */
public class Jugador {
    
    private int id;
    private float fondoFijo;
    private String nombre;
    private String colorFichas;
    List<Ficha> fichas= new ArrayList<>();
    private boolean vivo;
    private int turno;

    public Jugador(float fondoFijo, String nombre, String colorFichas, int turno) {
        this.fondoFijo = fondoFijo;
        this.nombre = nombre;
        this.colorFichas = colorFichas;
        this.turno = turno;
    }
    
    public void agregarFichas(Ficha f){
        fichas.add(f);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getFondoFijo() {
        return fondoFijo;
    }

    public void setFondoFijo(float fondoFijo) {
        this.fondoFijo = fondoFijo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getColorFichas() {
        return colorFichas;
    }

    public void setColorFichas(String colorFichas) {
        this.colorFichas = colorFichas;
    }

    public List<Ficha> getFichas() {
        return fichas;
    }

    public void setFichas(List<Ficha> fichas) {
        this.fichas = fichas;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public int getTurno() {
        return turno;
    }

    public void setTurno(int turno) {
        this.turno = turno;
    }
    
    
    
}
