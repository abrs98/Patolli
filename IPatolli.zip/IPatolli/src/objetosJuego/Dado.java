/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosJuego;

/**
 *
 * @author Abrahan Barrios
 */
public class Dado {
    
    private boolean punto=false;
    private int numeroDado;

    public Dado(int numeroDado) {
        this.numeroDado = numeroDado;
    }
    /**Metodo que calcula un numero aleatorio,
     * y si este es par, el dado genera un punto,
     * es decir, se establece a true la variable
     * punto
     * 
     */
    public void calcularSiEsPunto(){
   
}
    
   

}
