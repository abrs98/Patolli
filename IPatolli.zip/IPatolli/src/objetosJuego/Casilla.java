/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package objetosJuego;

import java.awt.Graphics;

/**
 *
 * @author Abrahan Barrios
 */
public class Casilla{
    
    private int numCasilla;
    private String tipo;
    private boolean ocupada;

    public Casilla(int numCasilla, String tipo, boolean ocupada) {
        this.numCasilla = numCasilla;
        this.tipo = tipo;
        this.ocupada = ocupada;
    }

    public int getNumCasilla() {
        return numCasilla;
    }

    public void setNumCasilla(int numCasilla) {
        this.numCasilla = numCasilla;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }
    
    
    
    
}
